package com.jspiders.multithreading.thread;

public class MyThread5 extends Thread {
	public void run() {
    	   System.out.println("My Thread is running...!");
       }

}
