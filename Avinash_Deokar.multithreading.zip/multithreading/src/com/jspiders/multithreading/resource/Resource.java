package com.jspiders.multithreading.resource;

public class Resource {

	public String res1="1st resource";
	public String res2="2nd resource";

}
