package com.jspiders.springmvc1;

public class App {

}
